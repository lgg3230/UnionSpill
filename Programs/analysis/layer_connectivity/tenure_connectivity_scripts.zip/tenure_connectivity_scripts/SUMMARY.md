# Tenure layer connectivity — construction scripts (orientation for a reader/AI)

This bundle contains the five scripts that build the **tenure (`ten2`) layer
connectivity** measure and the **tenure outcomes database** used by the
within-firm exhibits (Tables A6/A7/A8) of *Outside Options and Collective
Bargaining Spillovers* (Gomes & Neri).

Tenure groups: `lt12mo` (tenure < 12 months) and `ge12mo` (tenure >= 12 months).

**Key thing to understand first:** every script here except `layer_config.py` is
**layer-agnostic**. The identical code builds the education, gender, race,
occupation, and tenure measures. A run becomes "tenure" only because of the
`--layer ten2` command-line argument, which selects the `ten2` entry in
`layer_config.py`. The transition-counting and connectivity arithmetic never
inspect the group label — they operate on an opaque `layer_id` string. So to
understand what is *specific* to tenure, read only `layer_config.py`; to
understand the connectivity *construction*, read scripts 01a/02a/03a.

## Files in this bundle

```
layer_config.py                        <- the ONLY tenure-specific logic
00_pipeline/01a_build_transitions.py   <- per-worker flow records
00_pipeline/02a_aggregate.py           <- flows -> per-year-pair connectivity ratio
00_pipeline/03a_compute_n.py           <- average over pairs -> firm_layer_connectivity_ten2.dta
00_pipeline/06z_prep_outcomes_unified.py <- firm_layer_outcomes_ten2.dta (outcomes DB)
```

Run order:

```
python 00_pipeline/01a_build_transitions.py      --layer ten2
python 00_pipeline/02a_aggregate.py              --layer ten2
python 00_pipeline/03a_compute_n.py              --layer ten2
python 00_pipeline/06z_prep_outcomes_unified.py  --layer ten2
```

Requires Python 3.12 with `duckdb`, `pandas`, `numpy`, `pyarrow`. Scripts import
`layer_config` via `sys.path.insert(0, dirname(dirname(__file__)))`, so keep
`layer_config.py` one directory above `00_pipeline/` (as laid out here).

**Inputs** (built upstream by the main RAIS pipeline; NOT included here):
`worker_panel_lagos.parquet`, `yearly_employers_{year}.{parquet,dta}`, raw
`RAIS_{year}.{parquet,dta}`, `lagos_treat.csv`, `lagos_control.csv`.

---

## The connectivity measure in one paragraph

For establishment *i* and tenure group *g*, `layer_treat_pw_n` is the average,
over the four pre-treatment year pairs (2007-08, 2008-09, 2009-10, 2010-11), of

    (group-g workers of i who move to a treated firm
     + group-g workers of i who arrive from a treated firm)
    / (average group-g employment at i).

It is a per-worker rate at which firm *i*'s short-tenure (or long-tenure)
workforce is in labor-market contact with the directly-treated sector.

## Script-by-script

### `layer_config.py` — the only tenure-specific file
`LAYER_DEFS["ten2"]` tells the pipeline to read the raw RAIS column `tempempr`
(tenure in months) and bin it via `_ten2_pandas` / `_TEN2_SQL`:
`tempempr < 12 -> 'lt12mo'`, `>= 12 -> 'ge12mo'`. That 12-month cutoff is the
entire definition of the partition. The file also sets `YEAR_PAIRS`,
`PARQUET_ORIGIN_YEARS`/`PARQUET_DEST_YEARS` (which years read the cached worker
panel vs. raw RAIS), IPCA deflators, and all file paths.

### `00_pipeline/01a_build_transitions.py` — per-worker flow records
For each year pair (t, t+1), one record per focal worker:
- **Outflow**: worker at focal firm *i* in year *t* who moves to a treated firm
  in *t+1*. Group = his `tempempr` bin **at firm *i* in year *t***.
- **Inflow**: worker at focal firm *i* in year *t+1* who came from a treated firm
  in *t*. Group = his `tempempr` bin **at firm *i* in year *t+1***.

So the tenure that assigns the group is always tenure **at the focal firm**
(the firm whose connectivity we compute), in the year the worker is seen there.
It is origin tenure for outflows and destination tenure for inflows — never the
tenure at the *other* (treated) firm. `_merge_focal_layer` enforces this by
keeping the layer row only when the layer-firm equals the focal firm. Spell
filters: `empem3112 = 1` (employed on Dec 31) and `tempempr > 1`; one spell per
worker chosen by highest hours, then (for the focal firm) highest tenure.

Tenure-specific quirk worth flagging: because the grouping column (`tempempr`) is
*also* a spell-ranking key, a multi-bond worker's group is read off the spell that
was selected for being the longest. This interaction is inert for every other
layer (whose grouping column differs from the ranking keys).

Output: `transitions_base/transitions_ten2.parquet`.

### `00_pipeline/02a_aggregate.py` — flows -> per-year-pair ratio
Collapses records to (firm, group, year-pair):
`E_t` = group-g workers at *i* in year *t*; `E_t1` = group-g workers at *i* in
*t+1*; `E_avg = (E_t + E_t1)/2`; `M_total` = flows to/from treated for group g
(`SUM(is_treated_contact)`); **`ratio_total = M_total / E_avg`**. Also computes
same-layer / cross-layer splits and a total-mover-flow rate.
Output: `connectivity_components/{components,wide}_ten2.parquet`.

### `00_pipeline/03a_compute_n.py` — average over pairs -> final measure
NaN-aware mean of `ratio_total` across the four pairs (sum of available pairs /
count of available pairs) = **`layer_treat_pw_n`**, the connectivity variable the
regressions use. Same treatment for `sametreat_pw_n`, `crosstreat_pw_n`,
`totalflows_layer_pw_n`.
Output: `final_measures/firm_layer_connectivity_ten2.dta` (+ `.parquet`).

### `00_pipeline/06z_prep_outcomes_unified.py` — the outcomes database
Separate object: firm x tenure-group x year **outcomes** from the worker panel —
`layer_emp`, `lr_remdezr_layer` (log Dec real wage), `lr_remdezr_h_layer` (log
hourly), `l_layer_emp`, plus layer-level controls (mean hours/age, share
female/higher-ed/fixed-term). Group is again `tempempr < 12 / >= 12` per
firm-year cell; keeps only cells with positive employment, wage, and hours.
Output: `firm_layer_outcomes_ten2.dta` (+ `.parquet`).

---

## How these feed the paper

`firm_layer_connectivity_ten2.dta` (connectivity, in
`Data/layer_connectivity/final_measures/`) and `firm_layer_outcomes_ten2.dta`
(outcomes, in `Data/layer_connectivity/`) are merged on `identificad` x
`layer_id` by the within-firm estimation code
(`Programs/layer_connectivity/07_within_firm/01_within_firm_estimates.do`), which
produces Tables A6/A7/A8. `layer_treat_pw_n` is the connectivity regressor;
`lr_remdezr_layer` / `l_layer_emp` are the outcomes.

## Open interpretation note (for your coauthor)

Because the group is defined by tenure **at the focal firm** (above), the
`ge12mo` connectivity is dominated by the OUTFLOW side: long-tenured incumbents of
firm *i* being drawn toward treated firms. The `ge12mo` inflow side is nearly
empty by construction (a worker who just arrived at *i* has < 12 months tenure at
*i*), except for multi-bond edge cases. So the `ge12mo` measure supports a
"competitive pressure on established incumbents" reading, but it is NOT "long-
tenured workers arriving from treated firms." If the intended object were the
latter (tenure at the *prior* employer), scripts 01a would need to read the
contact-firm tenure instead of the focal-firm tenure.
